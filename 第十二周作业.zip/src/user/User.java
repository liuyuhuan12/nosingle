package user;

public interface User {
	public void generateCommucationRecord();
	public String getCallToPhoneNumber();
	public String accountFee(long timeStart,long timeEnd);
	public void printDetails();
}
