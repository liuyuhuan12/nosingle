package production;

import user.*;
public class HaHaUserProduce extends Produce{
	public User produceUser(){
		return new HaHaUser("17656319795");
	}
}
