package production;
import user.*;
public abstract class Produce {
	public abstract User produceUser();
}
