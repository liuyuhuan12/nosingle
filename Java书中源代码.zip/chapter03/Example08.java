class Person {
	int age;
	public Person(int x) {
		age = x;
	}
}
public class Example08 { 
	public static void main(String[] args) {
		Person p = new Person(); 	// ʵ���� Person ����
	}
}
