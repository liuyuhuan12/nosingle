package cn.itcast.utils;
public class ToolDemo {
	public static void run(){
		System.out.println("The ToolDemo is runing...");
	}
}
