import cn.itcast.utils.ToolDemo;
public class ImportJarTest {
	public static void main(String[] args) {
		ToolDemo.run();
	}
}
