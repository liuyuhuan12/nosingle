public class Example01 {
	public static void main(String[] args) {
		int num = 4;
		byte b = num;
		System.out.println(b);
	}
}
