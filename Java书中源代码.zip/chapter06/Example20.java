public class Example20{
	public static void main(String args[]) {
		Integer num = new Integer(20);
         int a = 10;
		int sum = num.intValue() + a;
		System.out.println("sum="+sum);
	}
}
