public class Example07 {
	public static void main(String[] args) {
		String s = "abcdedcba";              
		System.out.println(s.charAt(10));  
	}
}
