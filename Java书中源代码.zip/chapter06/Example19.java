public class Example19 {
	public static void main(String args[]) {
		int a = 20;
		Integer in = new Integer(a);
		System.out.println(in.toString());
	}
}
